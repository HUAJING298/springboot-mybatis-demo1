package com.example.springbootmydemo.Service;

import com.example.springbootmydemo.pojo.User;

public interface UserService {

    User loginQuery(User user);

    int insertQuery(User user);

}
