package com.example.springbootmydemo.Service;

import com.example.springbootmydemo.mapper.UserMapper;
import com.example.springbootmydemo.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceImplements implements UserService{
    @Autowired
    UserMapper usermapper;
    //登录
    @Override
    public User loginQuery(User user) {
//返回查询结果
        return usermapper.loginQuery(user);
    }
    // 注册
    @Override
    public int insertQuery(User user) {
        return usermapper.insertQuery(user);
    }



}
