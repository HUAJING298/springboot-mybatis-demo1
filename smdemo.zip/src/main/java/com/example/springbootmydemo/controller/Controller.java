package com.example.springbootmydemo.controller;

import com.example.springbootmydemo.Service.UserService;
import com.example.springbootmydemo.pojo.User;
import com.mysql.cj.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/user")
public class Controller {
    @Autowired
    UserService userService;



    @RequestMapping("/login")
    @ResponseBody
    public Object login(User user){
//判断是否为空
        if(StringUtils.isNullOrEmpty(user.getUsername()) && StringUtils.isNullOrEmpty(user.getPassword())) {
//不为空，到user中查找
            User users = userService.loginQuery(user);
//返回
            if(users != null) {
                System.out.println(users);
                return users;
            }else{
                return "fail";
            }
        }else {
            return "fail";
        }
    }
    @RequestMapping("/regist")
    @ResponseBody
    public Object insertQuery(User user) {
        if(StringUtils.isNullOrEmpty(user.getUsername()) && StringUtils.isNullOrEmpty(user.getPassword())) {
            //创建id
            user.setId(UUID.randomUUID().toString().replace("-", ""));
            int count = userService.insertQuery(user);
            if(count == 1) {
                return "success";
            }else {
                return "fail";
            }
        }else {
            return "fail";
        }
    }

}
