package com.example.springbootmydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootmyDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootmyDemoApplication.class, args);
    }

}
