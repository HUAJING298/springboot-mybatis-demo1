package com.example.springbootmydemo.mapper;

import com.example.springbootmydemo.pojo.User;
import org.apache.ibatis.annotations.Mapper;

import org.springframework.stereotype.Component;

@Mapper
@Component
public interface UserMapper {
    //    登陆后显示所有用户信息
    public User loginQuery(User user);
    //	插入一条用户信息，返回状态
    public int insertQuery(User user);



}
